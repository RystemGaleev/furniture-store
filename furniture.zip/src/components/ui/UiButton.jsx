export const UiButton = ({ children, variant }) => {
  return <button className={variant}>{children}</button>;
};
