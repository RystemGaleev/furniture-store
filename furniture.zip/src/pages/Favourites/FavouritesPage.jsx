import { useSelector } from 'react-redux';
import { ProductCard } from '../../components/ProductCard/ProductCard';
import { Layout } from '../../Layout/Layout';
import './Favourites.scss';

export const FavouritesPage = () => {
  const { favourites } = useSelector((state) => state.favourites);
  return (
    <Layout>
      <section className="favourites">
        <div className="container">
          <div className="favourites__wrapper">
            {favourites.map((item) => (
              <ProductCard key={item.id} {...item} />
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};
