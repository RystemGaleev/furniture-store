import React from 'react';
import { Layout } from '../../Layout/Layout';

export const ErrorPage = () => {
  return (
    <Layout>
      <div className="container">ErrorPage</div>
    </Layout>
  );
};
