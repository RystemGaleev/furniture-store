import { configureStore } from '@reduxjs/toolkit';
import products from './ProductSlice';
import cart from './CartSlice';
import SingleProduct from './CartSlice';
import favourites from './FavouritesSlice';

const store = configureStore({
  reducer: {
    products,
    cart,
    SingleProduct,
    favourites,
  },
});

export default store;
