// import { useState } from 'react';

// export const useModal = () => {
//   const [modalOpen, setModalOpen] = useState({
//     welcomModal: false,
//     thanksModal: false,
//     formModal: false,
//   });
//   const toggle = () => setModalOpen(!modalOpen);

//   return [modalOpen, setModalOpen, toggle];
// };
